#2.7
#Interactive fiction 
#Kimberly Carrera
#Introduction
def introduction():
  print "The Great Adventure of King Danial"
  print "In a Kingdom called Bridges deep within Iceland there was a king called Danial Boyd who was brave and adventures. He does not give up so easily."
  print "He grew bored of his kingdom and sought out adventure beyond iceland. Alexander, Philip, and Joseph are great friends of he king. They all decided to go on an adventure but Danial could not leave his Kingdom unsupervised."
  print "King Danial has to decide between his Geaneral Harold or his adviser Henry"
  print "DECISION: Decide to leave Henry or Harold in charge of the Kingdom, choose wisely! Type harold or henry"
  intro()

#DECISION 1
def intro():
  answer = raw_input()
  if answer == "harold" :
    print "You choose Harold to leave in charge of the Kingdom"
    harold()
  else:
    print "You choose Henry to leave in charge of the Kingdom"
    harold()


#both choices are the same for the rest of the story for now.
def harold():
  print "After leaving the Kingdom they were off to sea heading southwest. After long months at sea the ship comes across a straggler at sea. He looked as if the life in him was vanishing."
  print "The ship was very low on supplies from the long months at sea and could not bare to have another mouth to feed. Should you welcome him on board or leave him behind?"
  print "type leave or type help"
  decision_1()

#DECISION 2
def decision_1():
  answer = raw_input()
  if answer == "leave":
    print "You choose to leave him"
    leave_him()
  else:
    print "You choose welcome him on board"
    help_him()

# choice1
def leave_him():
  print "The ship finally sees land. Once they got closer the crew could see the natives emerging from the forest. After getting off the boat both groups aproached eachother with caution but peacefully met. The Natives and the Icelanders were both trying to communicate with eachother through a mix of sherades and words. Danail saw that the Natives had plenty of food and supplies that would greatly help them"
  print "You could decide to ask them for help or steal from them. Type steal or help "
  help_steal()


#choice2
def help_him():
  print "After helping the stranger on board the king offered some food to him. He was gratefull but he was very hungry and ate almost all the food throgh the month. It took nearlly another month to finally see land but by then it was to late."
  print "Two of your friends die, Phillip the rather annoying friend but very loyal and kind. The other was Joseph, a well trusted friend since childhood also died because of the lack of food."
  print "The ship finally sees land. Once they got closer the crew could see the natives emerging from the forest. After getting off the boat both groups aproached eachother with caution but peacefully met. The Natives and the Icelanders were both trying to communicate with eachother through a mix of sherades and words. Danail saw that the Natives had plenty of food and supplies that would greatly help them"
  print "You could decide to ask them for help or steal from them. Type steal or help "
  help_steal()



#DECISION 3
def help_steal():
  answer = raw_input()
  if answer == "steal":
    print "You choose to steal from the Natives"
    steal()
  else:
    print "You choose to ask for help from the Natives"
    ask_help()


#Choice 1 also ending 3
def steal():
  print "After stealing the food and supplies the Natives found out and were furious about what the king has done. They instantlly attacked the King Danial and his crew. It was an epic battle that the king lost his life. None of them made it or ever returned home"
  print "THE END"

#Choice 2
def ask_help():
  print "The Natives were very generous when asked for help. They gave King Danial enough supplies for him and his crew. The tribe and the King with his crew joined them for a grand feast. After months they deciced to head back with all the collected new plants, language and animals to bring back to the Kingdom of Bridges."
  print "After getting to the kingdom of Bridges who did you choose to leave in charge? Type harold or henry"
  decided()



#DECISION 4
def decided():
  answer = raw_input()
  if answer == "harold":
    print "You left Harold in charge"
    ending_2()
  else:
    print "You left Henry in charge"
    ending_1()


#choice 1
def ending_1():
  print "After you left Henry, King Danial returned to Bridges with everything better than it was before. Danial was very pleased by this. The citizens of Bridges enjoyed all the new discoveries brought by the King. The whole kingdon celebrated his return. Everything was at peace and new allies were made."
  print "THE END"


#chioce 2
def ending_2():
  print "After you had left Harold in charge this whole time he created chaos across the Kingdom. Everone was furious at the King for leaving him in charge. Now you are left to deal with this mess"
  print "THE END"

introduction()

